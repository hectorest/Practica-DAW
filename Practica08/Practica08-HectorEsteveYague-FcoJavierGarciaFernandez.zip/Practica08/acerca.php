
<?php

	require_once("head.php");
	require_once("header.php");

	if(isset($_SESSION["usuarioLog"])){
		require_once("barraNavSesionIniciada.php");
	}
	else{
		require_once("barraNavSesionNoIniciada.php");
	}
?>
		<section>
			<div class="contTabla">
				<table class="tabla" title="Puedes hacer scroll lateral en la tabla si no cabe en tu pantalla para poder ver todos los datos que contiene">
					<caption>Datos de los creadores:</caption>
					<tr>
						<td>Autores:</td>
						<td>Hector Esteve Yagüe & Fco. Javier García Fernández</td>
					</tr>
					<tr>
						<td>Asignatura:</td>
						<td>Desarrollo de Aplicaciones Web</td>
					</tr>
					<tr>
						<td>Grado:</td>
						<td>Ingenieria Multimedia</td>
					</tr>
					<tr>
						<td>Lugar de estudios:</td>
						<td>Universidad de Alicante</td>
					</tr>
					<tr>
						<td>Correo de contacto:</td>
						<td><a href="mailto:pidaw@gmail.es">pidaw@gmail.es</a></td>
					</tr>
					<tr>
						<td>Teléfono:</td>
						<td>645274186</td>
					</tr>
				</table>
			</div>
			<div>
				<h3>Descripción de Pictures & Images (PI)</h3>
				<p class="p-left">Esta aplicación web correspondiente a la creación de una plataforma online en la que se podrán subir fotos y comprar álbumes de las propias fotos que has subido tú a tu perfil, se corresponde con la práctica de la asignatura Desarrollo de Aplicaciones Web la cual se cursa en el Grado en Ingenieria Multimedia impartido en la Universidad de Alicante.</p>
			</div>
		</section>
<?php
	require_once("footer.php");
?>
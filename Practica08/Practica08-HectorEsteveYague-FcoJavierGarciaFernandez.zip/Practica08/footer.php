<?php
echo <<<footer
	<footer>
		<p><strong><a href="acerca.php" title="Información de contacto">&copy;Hector Esteve Yagüe & Fco. Javier García Fernández</a></strong><time datetime="2018-09">Septiembre de 2018</time><a href="#piCabec"><span class="icon-angle-circled-up" title="Subir al encabezado"></span></a></p>
		</footer>
	</body> 
</html>
footer;
?>
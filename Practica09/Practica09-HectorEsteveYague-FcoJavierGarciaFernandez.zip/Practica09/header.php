<?php
echo <<<header
<body>
		<header id="piCabec">
			<a href="index.php" title="Ir a la página de inicio"><img src="./logotipo-e-icono/logotipo-pi-daw.png" alt="logotipo de pictures & images"/></a>
			<div>
				<h1>Pictures & Images</h1>
				<h2>Tu aplicación web para fotos</h2>
			</div>
		</header>
	
header;
?>